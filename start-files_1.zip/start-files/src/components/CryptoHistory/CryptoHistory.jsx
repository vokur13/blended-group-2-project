import { BaseTable, THead, Th, Tr, Td } from './CryptoHistory.styled';

export const CryptoHistory = () => {
  return <div>CryptoHistory</div>;
};
